/*
* name;
*/
var Data = (function () {
    function Data() {
    }
    return Data;
}());
//# sourceMappingURL=Data.js.map